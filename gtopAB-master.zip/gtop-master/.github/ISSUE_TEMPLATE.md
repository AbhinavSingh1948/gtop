#### Environment

- OS:
- Node version: (`$ node --version`)
- gtop version: (`$ npm info gtop version`)

#### Description

*A description of the issue*
